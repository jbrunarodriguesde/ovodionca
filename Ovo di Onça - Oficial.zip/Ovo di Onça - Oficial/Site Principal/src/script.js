function enviarParaWhatsApp() {
    const nome = document.getElementById('nome').value.trim();
    const whatsapp = document.getElementById('whatsapp-form').value.trim();
    const bairro = document.getElementById('bairro').value.trim();
    const mensagem = document.getElementById('mensagem-interesse').value.trim();
  
    const texto = `
  Olá! Gostaria de fazer uma assinatura com a Ovo di Onça.
  Nome: ${nome}
  WhatsApp: ${whatsapp}
  Bairro: ${bairro || "Não informado"}
  Mensagem: ${mensagem || "—"}
    `.trim();
  
    const encoded = encodeURIComponent(texto);
    const numero = "553125167561";
  
    window.open(`https://wa.me/${numero}?text=${encoded}`, '_blank');
  }
  
  document.addEventListener('DOMContentLoaded', function () {
      // --- MENU HAMBÚRGUER ---
      const menuToggle = document.querySelector('.menu-toggle');
      const menu = document.querySelector('.menu-navegacao .menu');
      if (menuToggle && menu) {
          menuToggle.addEventListener('click', () => {
              menu.classList.toggle('show');
              menuToggle.setAttribute('aria-expanded', menu.classList.contains('show'));
          });
          document.querySelectorAll('.menu a').forEach(link => {
              link.addEventListener('click', () => {
                  menu.classList.remove('show');
                  menuToggle.setAttribute('aria-expanded', 'false');
              });
          });
      }
  
      // --- GALERIA DE FOTOS ---
      const slides = document.querySelectorAll('.slide');
      let indexAtual = Array.from(slides).findIndex(slide => slide.classList.contains('active'));
      if (indexAtual === -1 && slides.length > 0) {
          indexAtual = 0;
          slides[0].classList.add('active');
      }
  
      function atualizarSlides() {
          slides.forEach(slide => slide.classList.remove('active'));
          slides[indexAtual].classList.add('active');
      }
  
      window.mudarSlide = function(direcao) {
          indexAtual += direcao;
          if (indexAtual < 0) indexAtual = slides.length - 1;
          else if (indexAtual >= slides.length) indexAtual = 0;
          atualizarSlides();
      };
  
      slides.forEach((slide, index) => {
          slide.addEventListener('click', () => {
              indexAtual = index;
              atualizarSlides();
          });
      });
  
      // --- COPYRIGHT ---
      const yearSpan = document.getElementById('current-year');
      if (yearSpan) yearSpan.textContent = new Date().getFullYear();
  });
  
  // --- SIMULADOR DE PLANOS ---
  function mostrarPlano(plano) {
      const info = document.getElementById("info");
      if (!info) return;
  
      let texto = "";
      switch (plano) {
          case "semanal":
              texto = `
                  <strong>Plano Semanal</strong><br>
                  Receba ovos fresquinhos toda semana!<br><br>
                  <strong>Valor:</strong> R$ 180,00 por mês <br>
                  (1 pente/semana - R$ 45,00 cada)<br>
                  <a href="https://wa.me/553125167561?text=Olá!%20Quero%20assinar%20o%20Plano%20Semanal." class="btn">Assinar pelo WhatsApp</a>
              `;
              break;
          case "quinzenal":
              texto = `
                  <strong>Plano Quinzenal</strong><br>
                  Entregas a cada 15 dias.<br><br>
                  <strong>Valor:</strong> R$ 90,00 por mês <br>
                  (1 pente/quinzena - R$ 45,00 cada)<br>
                  <a href="https://wa.me/553125167561?text=Olá!%20Quero%20assinar%20o%20Plano%20Quinzenal." class="btn">Assinar pelo WhatsApp</a>
              `;
              break;
          case "mensal":
              texto = `
                  <strong>Plano Mensal</strong><br>
                  Receba uma entrega por mês.<br><br>
                  <strong>Valor:</strong> R$ 45,00 por pente <br>
                  (1 pente/mês)<br>
                  <a href="https://wa.me/553125167561?text=Olá!%20Quero%20assinar%20o%20Plano%20Mensal." class="btn">Assinar pelo WhatsApp</a>
              `;
              break;
      }
      info.innerHTML = texto;
      info.style.display = "block";
  }
  