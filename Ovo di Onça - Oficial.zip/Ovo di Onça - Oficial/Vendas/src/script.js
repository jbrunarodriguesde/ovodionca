document.getElementById("current-year").textContent = new Date().getFullYear();

  function toggleMenu() {
    document.getElementById('menu').classList.toggle('show');
  }

  function mostrarReceita(nome) {
    const receitas = {
      ovo: `<h2>Ovo Cozido Perfeito</h2><p><strong>Ingredientes:</strong></p><ul><li>Ovos caipiras Ovo di Onça</li><li>Água suficiente para cobrir</li></ul><p><strong>Modo de preparo:</strong></p><ol><li>Coloque os ovos numa panela com água fria.</li><li>Leve ao fogo médio e conte 7 a 10 minutos após levantar fervura.</li><li>Desligue, resfrie com água fria e descasque com cuidado.</li></ol>`,
      omelete: `<h2>Omelete Caipira</h2><p><strong>Ingredientes:</strong></p><ul><li>2 ovos caipira Ovo di Onça</li><li>1 pitada de sal</li><li>Queijo ralado e temperos a gosto</li></ul><p><strong>Modo de preparo:</strong></p><ol><li>Bata os ovos com os temperos.</li><li>Despeje em uma frigideira antiaderente untada.</li><li>Cozinhe em fogo baixo até firmar. Dobre e sirva!</li></ol>`,
      pave: `<h2>Pavê de Ovomaltine</h2><p><strong>Ingredientes:</strong></p><ul><li>1 lata de leite condensado</li><li>1 colher de manteiga</li><li>2 gemas de ovo caipira Ovo di Onça</li><li>1/2 xícara de Ovomaltine</li><li>Bolacha maisena</li></ul><p><strong>Modo de preparo:</strong></p><ol><li>Cozinhe o leite condensado, manteiga e gemas até engrossar.</li><li>Monte camadas de creme e bolacha. Finalize com Ovomaltine.</li><li>Leve à geladeira por 4h. Sirva gelado.</li></ol>`,
      biscoito: `<h2>Receita Biscoito de Queijo</h2><p><strong>Ingredientes:</strong></p><ul><li>1Kg de polvilho doce</li><li>1 copo de leite (240ml)</li><li>6 ovos caipira Ovo di Onça</li><li>200 a 250g de manteiga derretida</li><li>400g ou mais de queijo curado ralado</li><li>Sal a gosto</li></ul><p><strong>Modo de preparo:</strong></p><ol><li>Misture o polvilho e o leite com uma colher.</li><li>Adicione os ovos e a manteiga e misture com as mãos.</li><li>Acrescente o queijo e o sal. Amasse bem.</li><li>Se precisar, adicione mais leite até conseguir enrolar.</li><li>Enrole no formato desejado e leve ao forno pré-aquecido a 250°C por 30 min.</li><li>Depois abaixe para 200°C até dourar. Sirva quentinho!</li></ol>`,
      bolo: `<h2>Bolo de Fubá</h2><p><strong>Ingredientes:</strong></p><ul><li>3 ovos caipira Ovo di Onça</li><li>1 e 1/2 xícara de açúcar</li><li>1/2 xícara de óleo</li><li>1 xícara de leite</li><li>2 xícaras de fubá</li><li>1 colher de fermento em pó</li></ul><p><strong>Modo de preparo:</strong></p><ol><li>Preaqueça o forno a 180°C.</li><li>Em uma tigela, bata os ovos, o açúcar e o óleo até obter uma mistura homogênea.</li><li>Adicione o leite e o fubá, misturando bem até a massa ficar homogênea.</li><li>Adicione o fermento e misture delicadamente até incorporar.</li><li>Despeje a massa em uma forma untada e asse por cerca de 40-50 minutos ou até que um palito inserido no centro saia limpo.</li><li>Retire do forno e deixe esfriar antes de servir.</li></ol>`
    };

    const div = document.getElementById('receita-detalhe');
    div.innerHTML = `<button class='btn' onclick='fecharReceita()'>Fechar</button>` + (receitas[nome] || '<p>Receita não encontrada.</p>');
    div.style.display = 'block';
    div.scrollIntoView({ behavior: 'smooth' });
  }

  function fecharReceita() {
    const div = document.getElementById('receita-detalhe');
    div.style.display = 'none';
    div.innerHTML = '';
  }

  function toggleMenu() {
    document.getElementById('menu').classList.toggle('show');
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('reveal');
      }
    });
  }, { threshold: 0.2 });

  document.querySelectorAll('.bloco').forEach(bloco => {
    observer.observe(bloco);
  });